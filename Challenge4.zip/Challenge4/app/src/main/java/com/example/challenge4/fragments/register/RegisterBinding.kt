package com.example.challenge4.fragments.register
import androidx.databinding.*


class RegisterBinding {
    var headerText: String = ""
    var useOtherMethodsText: String = ""
    var registerButtonText: String = ""
    var loginText: String = ""
}