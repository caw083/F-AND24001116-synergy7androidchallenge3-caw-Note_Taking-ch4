package com.example.challenge4.fragments.list

class ListBinding {
    var logoutBindingText =""
}