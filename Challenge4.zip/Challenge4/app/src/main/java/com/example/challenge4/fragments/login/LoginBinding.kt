package com.example.challenge4.fragments.login

class LoginBinding {
    var userEmailt: String = ""
    var userPassword: String = ""
    var alreadyHaveAccount: String = ""
    var loginText: String = ""
    var newAccountText: String = ""
}